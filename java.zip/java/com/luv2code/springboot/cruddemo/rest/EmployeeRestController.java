package com.luv2code.springboot.cruddemo.rest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.luv2code.springboot.cruddemo.dao.EmployeeDAO;
import com.luv2code.springboot.cruddemo.entity.Employee;
import com.luv2code.springboot.cruddemo.serice.EmployeeService;

@RestController
@RequestMapping("/api")
public class EmployeeRestController {
	
	private EmployeeService employeeService;
	
	@Autowired
	public EmployeeRestController (EmployeeService employeeService)
	{
		this.employeeService = employeeService;
	}
	

	@GetMapping("/employees")
	public List<Employee> findAll()
	{
		
		List<Employee> emps = employeeService.findAll();
		
		if(emps == null)
		{
			throw new RuntimeException("No employees to show");
		}
		
		Comparator<Employee> cmp = new Comparator<Employee>()
				{

					@Override
					public int compare(Employee emp1, Employee emp2) {
						
						if(emp1.getEmpSalary() > emp2.getEmpSalary())
						{
							return +1;
						}else if(emp2.getEmpSalary()> emp1.getEmpSalary()) {
							
							return -1;
							
						}
						return 0;
					}
			
			
				};
		
		Collections.sort(emps,cmp);
		
		
		return emps;
	}
	
	@GetMapping("/employees/{employeeId}")
	public Employee getEmployee(@PathVariable int employeeId)
	{
		Employee theEmployee = employeeService.findById(employeeId);
		
		if(theEmployee == null)
		{
			throw new RuntimeException("Employee id not found"+ employeeId);
			
		}
		
		return theEmployee;
	}
	
	@PostMapping("/employees")
	public Employee addEmployee(@RequestBody Employee theEmployee)
	{
		//also just in case they pass an id in json ..set id to 0 (zero)
		//this is to force a save of new item .. instead of update
		
		theEmployee.setEmpId(0);
		
		employeeService.save(theEmployee);
		
		return theEmployee;
		
	}
	
	@PutMapping("/employees")
	public Employee updateEmployee(@RequestBody Employee theEmployee)
	{
		employeeService.save(theEmployee);
		
		return theEmployee;
	}
	
	@DeleteMapping("/employees/{employeeId}")
	public String deleteEmployee(@PathVariable int employeeId)
	{
		Employee tempEmployee = employeeService.findById(employeeId);
		
		if(tempEmployee == null)
		{
			throw new RuntimeException("Employee id not found"+employeeId);
			
		}
		
		employeeService.deleteById(employeeId);
		
		return "Deleted employee id -"+employeeId;
		
	}
	
	@GetMapping("/department/{dept}")
	public List<Employee> getEmpsByDepartment(@PathVariable String dept)
	{
		
		List<Employee> empList = employeeService.getEmpsByDepartment(dept);
		
		if(empList == null)
		{
			throw new RuntimeException("No.. Employees regards department "+dept);
		}
		
		
		
		
		return empList;
	}
	
	@GetMapping("/position/{pos}")
	public List<Employee> getEmpsByPosition(@PathVariable String pos)
	{
		List<Employee> empList = employeeService.getEmpsByPos(pos);
		
		if(empList == null)
		{
			throw new RuntimeException("No.. Employees regarding position"+pos);
		}
		
		
		
		return empList;
	}
	
	
	@GetMapping("/pagination/{offset}/{pageSize}")
	private List<Employee>  pagenation(@PathVariable int offset,@PathVariable int pageSize)
	{
		if(offset == 0 || pageSize == 0 )
		{
			throw new RuntimeException("Offset or Page Size cannot be zero ie.. it should start from 1");
		}
		List<Employee> myList = employeeService.findAll();
		
		Comparator<Employee> cmp = new Comparator<Employee>(){

			@Override
			public int compare(Employee emp1, Employee emp2) {
				
				if(emp1.getEmpId() > emp2.getEmpId()) {
					return +1;
				}else if(emp2.getEmpId() > emp1.getEmpId()){
					
					return -1;
					
				}
				
				return 0;
			}
			
		};
		
		Collections.sort(myList,cmp);
		
		int startPoint = offset*(pageSize-1);
		
		int endPoint = offset*(pageSize);
		
		if(myList.size() < endPoint)
		{
			endPoint = myList.size();
		}
		
		List<Employee> myPagenation = new ArrayList<>();
		
		for(int i=startPoint;i<endPoint;i++)
		{
			myPagenation.add(myList.get(i));
		}
		
		return myPagenation;
		
		
		
		
		
	}
	
	
	
	
	
	
}
