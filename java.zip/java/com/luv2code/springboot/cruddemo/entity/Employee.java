package com.luv2code.springboot.cruddemo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee")
public class Employee {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int empId;
	
	
	@Column(name="first_name")
	private String empFirstName;
	
	@Column(name="last_name")
	private String empLastName;
	
	@Column(name="salary")
	private int empSalary;
	
	@Column(name="department")
	private String empDepartment;
	
	@Column(name="position")
	private String empPosition;
	
	
	@Column(name="email")
	private String empEmailAddress;
	
	@Column(name="contact")
	private String empContactNumber;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpFirstName() {
		return empFirstName;
	}

	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}

	public String getEmpLastName() {
		return empLastName;
	}

	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}

	public int getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(int empSalary) {
		this.empSalary = empSalary;
	}

	public String getEmpDepartment() {
		return empDepartment;
	}

	public void setEmpDepartment(String empDepartment) {
		this.empDepartment = empDepartment;
	}

	public String getEmpPosition() {
		return empPosition;
	}

	public void setEmpPosition(String empPosition) {
		this.empPosition = empPosition;
	}

	public String getEmpEmailAddress() {
		return empEmailAddress;
	}

	public void setEmpEmailAddress(String empEmailAddress) {
		this.empEmailAddress = empEmailAddress;
	}

	public String getEmpContactNumber() {
		return empContactNumber;
	}

	public void setEmpContactNumber(String empContactNumber) {
		this.empContactNumber = empContactNumber;
	}

	public Employee(String empFirstName, String empLastName, int empSalary, String empDepartment, String empPosition,
			String empEmailAddress, String empContactNumber) {
		super();
		this.empFirstName = empFirstName;
		this.empLastName = empLastName;
		this.empSalary = empSalary;
		this.empDepartment = empDepartment;
		this.empPosition = empPosition;
		this.empEmailAddress = empEmailAddress;
		this.empContactNumber = empContactNumber;
	}
	
	
	
	public Employee()
	{
		
	}

}
