package com.luv2code.springboot.cruddemo.serice;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.luv2code.springboot.cruddemo.dao.EmployeeDAO;
import com.luv2code.springboot.cruddemo.entity.Employee;
import com.luv2code.springdemo.exceptionDemo.NoEmployee;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	private EmployeeDAO employeeDAO;
	
	public EmployeeServiceImpl(EmployeeDAO employeeDAO)
	{
		this.employeeDAO = employeeDAO;
		
	}

	@Override
	@Transactional
	public List<Employee> findAll()  {
		
		try {
			if(employeeDAO.findAll() == null)
			{
				throw new NoEmployee("There are no employees to show");
			}
		}catch(NoEmployee emp)
		{
			System.out.println("There are no employees to show");
		}
		
		return employeeDAO.findAll();
		
		
	}

	@Override
	@Transactional
	public Employee findById(int theId) {
		
		try {
			if(employeeDAO.findById(theId) == null)
			{
				throw new NoEmployee("No Employee found of Id"+theId);
			}
		}
		catch(NoEmployee emp)
		{
			System.out.println("No Employee found of Id\"+theId");
		}
		
		return employeeDAO.findById(theId);
	}

	@Override
	@Transactional
	public void save(Employee theEmployee) {
		
		
		employeeDAO.save(theEmployee);

	}

	@Override
	@Transactional
	public void deleteById(int theId) {
		
		
		
		employeeDAO.deleteById(theId);

	}

	@Override
	@Transactional
	public List<Employee> getEmpsByDepartment(String dept) {
		
		
		return employeeDAO.getEmpsByDept(dept);
	}

	@Override
	@Transactional
	public List<Employee> getEmpsByPos(String pos) {
		
		return employeeDAO.getEmpsByPos(pos);
	}

	

}
