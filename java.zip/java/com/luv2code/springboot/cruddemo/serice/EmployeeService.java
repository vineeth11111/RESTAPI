package com.luv2code.springboot.cruddemo.serice;

import java.util.List;

import org.springframework.data.domain.Page;

import com.luv2code.springboot.cruddemo.entity.Employee;
import com.luv2code.springdemo.exceptionDemo.NoEmployee;

public interface EmployeeService {
	
	public List<Employee> findAll();
	
	public Employee findById(int theId);
	
	public void save(Employee theEmployee);
	
	public void deleteById(int theId);

	public List<Employee> getEmpsByDepartment(String dept);

	public List<Employee> getEmpsByPos(String pos);

	

}
