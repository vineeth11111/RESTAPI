package com.luv2code.springboot.cruddemo.dao;

import java.util.List;

import com.luv2code.springboot.cruddemo.entity.Employee;

public interface EmployeeDAO {
	
	public List<Employee> findAll();

	public Employee findById(int Id);
	
	public void save(Employee employee);
	
	public void deleteById(int id);

	public List<Employee> getEmpsByDept(String dept);

	public List<Employee> getEmpsByPos(String pos);

	
}
