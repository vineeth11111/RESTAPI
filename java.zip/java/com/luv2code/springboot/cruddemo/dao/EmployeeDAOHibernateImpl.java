package com.luv2code.springboot.cruddemo.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.luv2code.springboot.cruddemo.entity.Employee;

@Repository
public class EmployeeDAOHibernateImpl implements EmployeeDAO {

	

	//define field for entityManager
	private EntityManager entityManager;
	
	//set up constructor injection
	@Autowired
	public EmployeeDAOHibernateImpl(EntityManager entityManager)
	{
		this.entityManager = entityManager;
	}
	
	
	@Override
	public List<Employee> findAll() {
		
		//get the current hibernate session
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		//create the query
		
		Query<Employee> theQuery = 
				currentSession.createQuery("from Employee",Employee.class);
		
		//execute query and get result list
		
		List<Employee> employees = theQuery.getResultList();
		
		//return result set
		return employees;
	}


	@Override
	public Employee findById(int Id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Employee employee = currentSession.get(Employee.class, Id);		
		
		return employee;
	}


	@Override
	public void save(Employee employee) {
		
	
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		currentSession.saveOrUpdate(employee);
	}


	@Override
	public void deleteById(int id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Query theQuery = 
				currentSession.
				createQuery("delete from Employee where id=:employeeId");
		
		theQuery.setParameter("employeeId", id);
		
		theQuery.executeUpdate();
		
		
	}


	@Override
	public List<Employee> getEmpsByDept(String dept) {
	
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Query theQuery = currentSession.
				createQuery("from Employee where empDepartment=:deptId",Employee.class);
		
		theQuery.setParameter("deptId", dept);
		
		
		return theQuery.getResultList();
	}


	@Override
	public List<Employee> getEmpsByPos(String pos) {
		
Session currentSession = entityManager.unwrap(Session.class);
		
		Query theQuery = currentSession.
				createQuery("from Employee where empPosition=:position",Employee.class);
		
		theQuery.setParameter("position", pos);
		
		
		return theQuery.getResultList();
		
	
	}


	

}
