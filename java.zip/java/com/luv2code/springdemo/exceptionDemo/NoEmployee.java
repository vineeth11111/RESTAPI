package com.luv2code.springdemo.exceptionDemo;

public class NoEmployee extends Exception {
	
	public NoEmployee()
	{
		System.out.println("NO employee to show");
	}
	
	public NoEmployee(String message)
	{
		System.out.println(message);
	}

	

}
